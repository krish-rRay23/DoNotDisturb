# Do Not Disturb: When Plasticity Interventions Degrade Offline-to-Online Reinforcement Learning

### Anonymous Submission to ICLR 2027 (Supplementary Material)

This archive contains the complete, self-contained open-source research codebase, configuration files, test suite, and compact final empirical evaluation logs required to replicate and verify all findings, tables, figures, and statistical tests reported in the ICLR 2027 submission:

> **"Do Not Disturb: When Plasticity Interventions Degrade Offline-to-Online Reinforcement Learning"**

---

## 1. Quick Start: Reproduce All Paper Tables & Figures in 1 Minute

We provide a zero-configuration reproduction script that directly evaluates the included compact benchmark results and reproduces all tables, figures, and statistical tests without requiring GPU compute or raw dataset downloads:

```bash
# 1. Install standard lightweight dependencies
pip install -r requirements.txt
# or: pip install -e .

# 2. Run the complete reproduction pipeline
python experiments/reproduce_all_tables_and_figures.py
```

### Expected Output:
- **Table 1**: Complete 135-run Confirmatory Benchmark matrix (3 environments x 3 regimes x 3 arms) with exact means, standard deviations, and Interquartile Mean (IQM):
  - Baseline (None) IQM: **38.78** [95% CI: 37.43, 40.06]
  - Fixed (Shrink-Perturb) IQM: **12.30** [95% CI: 9.31, 15.23]
  - CapacityGate IQM: **38.78** [95% CI: 37.43, 40.06]
  - Paired Wilcoxon Signed-Rank Test: **W = 18.0, p = 1.44e-11**, Mean paired difference: **+26.03 +/- 19.09**
- **Table 2**: 24-run Non-Stationary Stress Study (Actuator Crippling at Step 5,000):
  - Walker2d: Fixed ($-0.53 \pm 0.33$) vs ReDo ($8.03 \pm 1.57$) demonstrating the operator stability asymmetry.
  - HalfCheetah: Fixed ($15.27 \pm 2.93$) vs ReDo ($13.64 \pm 3.18$) vs Baseline ($6.23 \pm 1.53$).
- **Figures Generated** (saved to `results/reproduced_figures/`):
  - `figure1_aggregate_iqm_improvement.png`: Aggregate Normalized Return IQM with 95% stratified bootstrap CIs and pairwise probability of improvement.
  - `figure2_online_adaptation_learning_curves.png`: 25,000-step online adaptation trajectories across all 9 experimental cells.
  - `figure3_stress_operator_asymmetry.png`: Physical stress study demonstrating operator stability asymmetry under bipedal locomotion constraints.

---

## 2. Repository Structure

```
.
├── configs/
│   ├── base.yaml                       # Default hyperparameters & network architecture
│   └── final_confirmatory_m10.yaml     # M10 reference configuration
├── data/
│   └── manifests/                      # Cryptographic SHA256 provenance manifests for D4RL datasets
│       ├── halfcheetah-medium-v2.json
│       ├── halfcheetah-medium-replay-v2.json
│       ├── hopper-medium-v2.json
│       ├── hopper-medium-replay-v2.json
│       ├── walker2d-medium-v2.json
│       └── walker2d-medium-replay-v2.json
├── experiments/
│   ├── reproduce_all_tables_and_figures.py # Master 1-command paper replication script
│   ├── final_analysis.py               # Statistical evaluation & audit suite
│   ├── stress_analysis.py              # Physical non-stationarity diagnostics
│   ├── final_factorial.py              # 135-run primary confirmatory factorial runner
│   ├── stress_factorial.py             # 24-run non-stationary stress runner
│   ├── mechanistic_stress_test.py      # Dual-probe actuator crippling test suite
│   ├── run_overnight.py                # Distributed execution harness
│   └── benchmark_concurrency.py        # Process & thread concurrency benchmark
├── pyproject.toml                      # Standard Python packaging specification
├── requirements.txt                    # Pinned Python package dependencies
├── results/
│   ├── final_study/                    # Compact run directories for all 135 primary runs
│   ├── stress_study/                   # Compact run directories for all 24 stress runs
│   ├── final_analysis/                 # Aggregated evaluation plots and curves
│   ├── stress_analysis/                # Dual-probe telemetry traces and summary tables
│   ├── reproduced_figures/             # Generated figures from reproduction script
│   ├── FINAL_paper_tables.csv          # Per-cell tabulated scores
│   └── FINAL_rliable_scores.csv        # Evaluated rliable normalized returns
├── src/adaptive_plasticity/
│   ├── capacity_gate.py                # Closed-loop CapacityGate diagnostic controller
│   ├── interventions.py                # Parameter intervention operators (Shrink-Perturb, ReDo)
│   ├── final_runner.py                 # Resilient online adaptation runner
│   ├── offline_cache.py                # Decoupled offline pretraining & validation cache
│   ├── distribution_shifts.py          # Observation noise, reward scaling & actuator crippling
│   ├── iql.py                          # Implicit Q-Learning (IQL) baseline implementation
│   └── m6.py                           # Effective rank (sRank) & dormancy diagnostics
└── tests/                              # Pytest test suite (>88 unit and integration tests)
```

---

## 3. Installation & Environment Setup

The code is developed and tested on Python 3.11+.

### Prerequisites:
```bash
python -m venv .venv

# Linux/macOS:
source .venv/bin/activate

# Windows:
.\.venv\Scripts\Activate.ps1

pip install --upgrade pip
pip install -r requirements.txt
pip install -e .
```

---

## 4. Running Tests

To verify package installation and internal mathematical routines:

```bash
# Run the complete test suite
pytest tests/ -q

# Test CapacityGate controller and refractory logic
pytest tests/test_capacity_gate.py -v

# Test parameter intervention operators (Shrink-and-Perturb & ReDo)
pytest tests/test_interventions.py -v

# Test protocol specifications and distribution shifts
pytest tests/test_final_protocol.py -v
```

---

## 5. End-to-End Training Reproduction (Optional)

If reproducing the full training pipeline from scratch:

1. **Obtain D4RL datasets**: The datasets correspond to standard Gym continuous control locomotion tasks (`halfcheetah-medium-v2`, `hopper-medium-v2`, `walker2d-medium-v2`). SHA256 checksums are verified against `data/manifests/`.
2. **Run Primary 135-Run Benchmark Suite**:
   ```bash
   python experiments/final_factorial.py --workers 4
   ```
3. **Run Non-Stationary Stress Study Suite**:
   ```bash
   python experiments/stress_factorial.py --workers 2
   ```
4. **Audit and Analyze Results**:
   ```bash
   python experiments/final_analysis.py --results-dir results/final_study
   python experiments/stress_analysis.py --indir results/stress_study
   ```
